package com.assignment.dfoe;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.assignment.dfoe.Adapters.HitsAdapter;
import com.assignment.dfoe.model.Hit;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


/*
 * Created by - Shashikant Vishwakarma
 * Mobile - 7760593180
 * Email ID - activity.shashi1403@gmail.com
 * */
public class MainActivity extends AppCompatActivity {
    private static final String TAG = MainActivity.class.getSimpleName();

    private HitsAdapter adapter;
    private ArrayAdapter array_adapter;
    private ArrayList<String> myArray;
    private AutoCompleteTextView autoCompleteTextView;
    private RequestQueue mRequestQueue;
    private StringRequest mStringRequest;
    private LinearLayout mll_object_actual_data;
    private List<Hit> list_data;
    private RecyclerView rv;
    public static ProgressDialog mProgressDialog;
    private TextView mTv_selected_object_id, mTv_selected_title, mTv_selected_points, mTv_selected_author, mTv_selected_children_comment, mTv_try_again, mTv_back_to_home;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rv = (RecyclerView) findViewById(R.id.recycler_view);
        rv.setHasFixedSize(false);
        rv.setVisibility(View.VISIBLE);
        rv.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

        list_data = new ArrayList<>();
        myArray = new ArrayList<>();

        array_adapter = new ArrayAdapter(this, R.layout.dropdown_autosuggestion_list, R.id.tv_order_hint_completion, myArray);

        //declaring all the layouts
        declaringLayouts();

        //get all hits of the data
        getAllHitsDataList();

        //loading auto suggestion data
        loadObjectSuggestionData();

        mTv_back_to_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rv.setVisibility(View.VISIBLE);
                mTv_try_again.setVisibility(View.GONE);
                mTv_back_to_home.setVisibility(View.GONE);
                mll_object_actual_data.setVisibility(View.GONE);
                autoCompleteTextView.setText("");
                getAllHitsDataList();
            }
        });
    }

    private void loadObjectSuggestionData() {

        //RequestQueue initialized
        mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        String url = "https://hn.algolia.com/api/v1/search?query=test";

        Log.d(TAG, "from loadObjectSuggestionData URL : " + url);

        //String Request initialized
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d(TAG, "response- " + response);

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("hits");

                            for (int i = 0; i < jsonArray.length(); i++) {

                                JSONObject receive = jsonArray.getJSONObject(i);
                                myArray.add(receive.getString("objectID"));

                            }
                            autoCompleteTextView.setThreshold(1);
                            autoCompleteTextView.setAdapter(array_adapter);
                            autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                                    imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);

                                    final String autoSuggestion = autoCompleteTextView.getText().toString().trim();
                                    String urlSuggestion = "https://hn.algolia.com/api/v1/items/" + autoSuggestion;
                                    rv.setVisibility(View.GONE);

                                    mProgressDialog = new ProgressDialog(MainActivity.this);
                                    mProgressDialog.setCancelable(true);
                                    mProgressDialog.show();
                                    mProgressDialog.setContentView(R.layout.custom_dailog);
                                    mProgressDialog.getWindow().setBackgroundDrawableResource(
                                            android.R.color.transparent
                                    );


                                    Log.d(TAG, "onItemClick: " + urlSuggestion);
                                    StringRequest stringReqSuggestionView = new StringRequest(Request.Method.GET, urlSuggestion,
                                            new Response.Listener<String>() {
                                                @Override
                                                public void onResponse(String response) {
                                                    mll_object_actual_data.setVisibility(View.VISIBLE);
                                                    mTv_try_again.setVisibility(View.GONE);
                                                    mTv_back_to_home.setVisibility(View.VISIBLE);
                                                    mProgressDialog.dismiss();
                                                    Log.d(TAG, "onClick suggestion response- " + response);

                                                    try {
                                                        JSONObject jsonObject1 = new JSONObject(response);
                                                        for (int i = 0; i < jsonObject1.length(); i++) {
                                                            String id = jsonObject1.getString("id");
                                                            String title = jsonObject1.getString("title");
                                                            String points = jsonObject1.getString("points");
                                                            String author = jsonObject1.getString("author");

//
                                                            JSONArray jsonArray1 = jsonObject1.getJSONArray("children");

                                                            if (jsonArray1 != null && jsonArray1.length() > 0) {

                                                                for (int j = 0; j < jsonArray1.length(); j++) {

                                                                    JSONObject fileObj = jsonArray1.getJSONObject(j);

                                                                    String children_text = fileObj.getString("text");
                                                                    mTv_selected_children_comment.setText(children_text);

                                                                    Log.d(TAG, "onResponse: children_text :: " + children_text);

                                                                }
                                                            }

                                                            Log.d(TAG, "onResponse: id :: " + id);
                                                            Log.d(TAG, "onResponse: title :: " + title);
                                                            Log.d(TAG, "onResponse: points :: " + points);
                                                            Log.d(TAG, "onResponse: author :: " + author);

                                                            mTv_selected_object_id.setText(id);
                                                            mTv_selected_title.setText(title);
                                                            mTv_selected_points.setText(points);
                                                            mTv_selected_author.setText(author);

                                                        }
                                                    } catch (JSONException ex) {
                                                        ex.printStackTrace();
                                                    }
                                                }
                                            }, new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {
                                            mProgressDialog.dismiss();
                                            mll_object_actual_data.setVisibility(View.GONE);
                                            mTv_try_again.setVisibility(View.VISIBLE);
                                            mTv_back_to_home.setVisibility(View.VISIBLE);

                                        }
                                    });
                                    adapter.notifyDataSetChanged();
                                    mRequestQueue.getCache().clear();
                                    mRequestQueue.add(stringReqSuggestionView);
                                }
                            });


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mProgressDialog.dismiss();
                mll_object_actual_data.setVisibility(View.GONE);
                mTv_try_again.setVisibility(View.VISIBLE);
                mTv_back_to_home.setVisibility(View.VISIBLE);

                Log.i(TAG, "VolleyError :" + error.toString());
            }
        });
        mRequestQueue.getCache().clear();
        mRequestQueue.add(stringRequest);

    }

    private void declaringLayouts() {
        autoCompleteTextView = (AutoCompleteTextView) findViewById(R.id.search_order_id_list);
        mll_object_actual_data = (LinearLayout) findViewById(R.id.ll_object_actual_data);
        mTv_selected_object_id = (TextView) findViewById(R.id.tv_object_id);
        mTv_selected_points = (TextView) findViewById(R.id.tv_points);
        mTv_selected_title = (TextView) findViewById(R.id.tv_title);
        mTv_try_again = (TextView) findViewById(R.id.tv_try_again);
        mTv_selected_author = (TextView) findViewById(R.id.tv_author);
        mTv_selected_children_comment = (TextView) findViewById(R.id.tv_children_comment);
        mTv_back_to_home = (TextView) findViewById(R.id.tv_back_to_home);
    }

    private void getAllHitsDataList() {
        mProgressDialog = new ProgressDialog(MainActivity.this);
        mProgressDialog.setCancelable(true);
        mProgressDialog.show();
        mProgressDialog.setContentView(R.layout.custom_dailog);
        mProgressDialog.getWindow().setBackgroundDrawableResource(
                android.R.color.transparent
        );
        mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        String url = "https://hn.algolia.com/api/v1/search?query=test";
        Log.d(TAG, "url : " + url);
        //String Request initialized
        mStringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mProgressDialog.dismiss();
                        try {

                            Log.d(TAG, "url >>>>> : " + response);

                            JSONObject json = new JSONObject(response);

                            try {
                                mProgressDialog.dismiss();
                                JSONObject jsonObject = new JSONObject(response);
                                JSONArray jsonArray = jsonObject.getJSONArray("hits");
                                Log.d(TAG, "onResponse: " + jsonArray);

                                if (jsonArray != null && jsonArray.length() > 0) {

                                    for (int i = 0; i < jsonArray.length(); i++) {
                                        mProgressDialog.dismiss();
                                        JSONObject fileObj = jsonArray.getJSONObject(i);

                                        String created_at = fileObj.getString("created_at");
                                        String title = fileObj.getString("title");
                                        String url = fileObj.getString("url");
                                        String author = fileObj.getString("author");
                                        String points = fileObj.getString("points");
                                        String story_text = fileObj.getString("story_text");
                                        String comment_text = fileObj.getString("comment_text");
                                        String num_comments = fileObj.getString("num_comments");
                                        String story_id = fileObj.getString("story_id");
                                        String story_title = fileObj.getString("story_title");
                                        String story_url = fileObj.getString("story_url");
                                        String parent_id = fileObj.getString("parent_id");
                                        String created_at_i = fileObj.getString("created_at_i");
                                        String objectID = fileObj.getString("objectID");

                                        Log.d("Hits Details :::: ", created_at + "," + title + "," + author + "," + points + "," + objectID);

                                        Hit hitListData = new Hit(created_at, title, url, author, points, story_text, comment_text, num_comments, story_id, story_title, story_url, parent_id, created_at_i, objectID);
                                        list_data.add(0, hitListData);
                                        rv.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                                        adapter = new HitsAdapter(MainActivity.this, list_data);
                                        rv.setAdapter(adapter);
                                        adapter.notifyDataSetChanged();
                                        mProgressDialog.dismiss();
                                    }
                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mProgressDialog.dismiss();
                Log.i("VolleyError", "Error :" + error.toString());
            }
        }) {
            @Override
            public String getBodyContentType() {
                return "application/json; charset=utf-8";
            }
        };
        mRequestQueue.getCache().clear();
        mRequestQueue.add(mStringRequest);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        getAllHitsDataList();

    }

    @Override
    protected void onResume() {
        super.onResume();
        getAllHitsDataList();

    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}