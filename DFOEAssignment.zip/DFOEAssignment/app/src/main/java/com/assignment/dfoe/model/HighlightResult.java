package com.assignment.dfoe.model;

public class HighlightResult{
    public Title title;
    public Url url;
    public Author author;
    public StoryText story_text;
}
