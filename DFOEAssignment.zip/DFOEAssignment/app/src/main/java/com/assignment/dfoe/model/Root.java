package com.assignment.dfoe.model;

import java.util.List;

public class Root{
    public List<Hit> hits;
    public int nbHits;
    public int page;
    public int nbPages;
    public int hitsPerPage;
    public boolean exhaustiveNbHits;
    public String query;
    public String params;
    public int processingTimeMS;
}
