package com.assignment.dfoe.model;

import java.util.List;

public class Title{
    public String value;
    public String matchLevel;
    public boolean fullyHighlighted;
    public List<String> matchedWords;
}
