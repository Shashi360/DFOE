package com.assignment.dfoe.model;

/*
 * Created by - Shashikant Vishwakarma
 * Mobile - 7760593180
 * Email ID - activity.shashi1403@gmail.com
 * */

public class Hit {

    public Hit(String created_at, String title, String url, String author, String points, String story_text, String comment_text, String num_comments, String story_id, String story_title, String story_url, String parent_id, String created_at_i, String objectID) {
        this.created_at = created_at;
        this.title = title;
        this.url = url;
        this.author = author;
        this.points = points;
        this.story_text = story_text;
        this.comment_text = comment_text;
        this.num_comments = num_comments;
        this.story_id = story_id;
        this.story_title = story_title;
        this.story_url = story_url;
        this.parent_id = parent_id;
        this.created_at_i = created_at_i;
        this.objectID = objectID;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPoints() {
        return points;
    }

    public void setPoints(String points) {
        this.points = points;
    }

    public String getStory_text() {
        return story_text;
    }

    public void setStory_text(String story_text) {
        this.story_text = story_text;
    }

    public String getComment_text() {
        return comment_text;
    }

    public void setComment_text(String comment_text) {
        this.comment_text = comment_text;
    }

    public String getNum_comments() {
        return num_comments;
    }

    public void setNum_comments(String num_comments) {
        this.num_comments = num_comments;
    }

    public String getStory_id() {
        return story_id;
    }

    public void setStory_id(String story_id) {
        this.story_id = story_id;
    }

    public String getStory_title() {
        return story_title;
    }

    public void setStory_title(String story_title) {
        this.story_title = story_title;
    }

    public String getStory_url() {
        return story_url;
    }

    public void setStory_url(String story_url) {
        this.story_url = story_url;
    }

    public String getParent_id() {
        return parent_id;
    }

    public void setParent_id(String parent_id) {
        this.parent_id = parent_id;
    }

    public String getCreated_at_i() {
        return created_at_i;
    }

    public void setCreated_at_i(String created_at_i) {
        this.created_at_i = created_at_i;
    }

    public String getRelevancy_score() {
        return relevancy_score;
    }

    public void setRelevancy_score(String relevancy_score) {
        this.relevancy_score = relevancy_score;
    }

    public String getObjectID() {
        return objectID;
    }

    public void setObjectID(String objectID) {
        this.objectID = objectID;
    }

    public String created_at;
    public String title;
    public String url;
    public String author;
    public String points;
    public String story_text;
    public String comment_text;
    public String num_comments;
    public String story_id;
    public String story_title;
    public String story_url;
    public String parent_id;
    public String created_at_i;
    public String relevancy_score;
    //    public List<String> _tags;
    public String objectID;
//    public HighlightResult _highlightResult;


}
