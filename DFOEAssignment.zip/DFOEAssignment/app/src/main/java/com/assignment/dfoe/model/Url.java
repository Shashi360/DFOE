package com.assignment.dfoe.model;

import java.util.List;

public class Url{
    public String value;
    public String matchLevel;
    public boolean fullyHighlighted;
    public List<String> matchedWords;
}
