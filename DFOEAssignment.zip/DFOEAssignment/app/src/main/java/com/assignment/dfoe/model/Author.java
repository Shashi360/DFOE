package com.assignment.dfoe.model;

import java.util.List;
/*
 * Created by - Shashikant Vishwakarma
 * Mobile - 7760593180
 * Email ID - activity.shashi1403@gmail.com
 * */


public class Author {
    public Author(String value, String matchLevel, List<Object> matchedWords) {
        this.value = value;
        this.matchLevel = matchLevel;
        this.matchedWords = matchedWords;
    }

    public String value;
    public String matchLevel;
    public List<Object> matchedWords;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getMatchLevel() {
        return matchLevel;
    }

    public void setMatchLevel(String matchLevel) {
        this.matchLevel = matchLevel;
    }

    public List<Object> getMatchedWords() {
        return matchedWords;
    }

    public void setMatchedWords(List<Object> matchedWords) {
        this.matchedWords = matchedWords;
    }
}
