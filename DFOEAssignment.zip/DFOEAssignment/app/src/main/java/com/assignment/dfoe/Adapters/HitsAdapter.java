package com.assignment.dfoe.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.assignment.dfoe.R;
import com.assignment.dfoe.model.Hit;

import java.util.List;

/*
 * Created by - Shashikant Vishwakarma
 * Mobile - 7760593180
 * Email ID - activity.shashi1403@gmail.com
 * */

public class HitsAdapter extends RecyclerView.Adapter<HitsAdapter.MyViewHolder> {
    private final Context context;
    private List<Hit> hitList;

    public HitsAdapter(Context context, List<Hit> hitList) {
        this.hitList = hitList;
        this.context = context;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView title, author, points, object_id, created_at;

        public MyViewHolder(View view) {
            super(view);
            title = (TextView) view.findViewById(R.id.tv_row_title);
            author = (TextView) view.findViewById(R.id.tv_row_author);
            points = (TextView) view.findViewById(R.id.tv_row_points);
            object_id = (TextView) view.findViewById(R.id.tv_row_object_id);
            created_at = (TextView) view.findViewById(R.id.tv_row_created_at);
        }
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_recycler_view_data, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Hit hit = hitList.get(position);

        holder.title.setText(hit.getTitle());
        holder.author.setText(hit.getAuthor());
        holder.points.setText(hit.getPoints());
        holder.object_id.setText(hit.getObjectID());
        holder.created_at.setText(hit.getCreated_at());
    }

    @Override
    public int getItemCount() {
        return hitList.size();
    }
}
