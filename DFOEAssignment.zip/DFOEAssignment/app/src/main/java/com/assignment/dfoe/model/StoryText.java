package com.assignment.dfoe.model;

import java.util.List;

public class StoryText{
    public String value;
    public String matchLevel;
    public List<Object> matchedWords;
}
